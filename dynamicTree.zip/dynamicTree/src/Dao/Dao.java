package Dao;

import java.util.List;

import Dto.MemberVO;

public interface Dao {
	// R
	public List<MemberVO> selectKey(int parentKey) throws Exception;
	
	public List<MemberVO> selectOneId(int id) throws Exception;
}
